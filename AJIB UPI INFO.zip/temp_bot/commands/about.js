/*CMD
  command: /about
  help: About this bot
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: about, info
CMD*/

var aboutMsg = "🔍 *UPI INFO LOOKUP BOT* 🔍\n\n";
aboutMsg += "Version: 1.0\n";
aboutMsg += "Created by: NinjaTech AI\n\n";
aboutMsg += "*Description*:\n";
aboutMsg += "UPI Info Lookup Bot kisi bhi UPI ID ki information extract kar sakta hai. Is bot ka use scammers ko track karne aur fraud se bachne ke liye kiya ja sakta hai.\n\n";
aboutMsg += "*Features*:\n";
aboutMsg += "• UPI ID validation\n";
aboutMsg += "• Account holder information\n";
aboutMsg += "• Bank details extraction\n";
aboutMsg += "• Location information\n";
aboutMsg += "• Contact details (if available)\n";
aboutMsg += "• Lookup history tracking\n\n";
aboutMsg += "*Disclaimer*:\n";
aboutMsg += "Is bot ka use sirf educational aur security purposes ke liye kare. Kisi ka personal data misuse karna illegal hai. Bot developer kisi bhi misuse ke liye responsible nahi hai.\n\n";
aboutMsg += "*How to Use*:\n";
aboutMsg += "Kisi bhi UPI ID ki information nikalne ke liye, bas ye command use karo:\n";
aboutMsg += "👉 `/upiinfo [UPI ID]`\n\n";
aboutMsg += "Example: `/upiinfo example@okicici`";

Bot.sendMessage(aboutMsg);

// Show main options again
var keyboard = [
  [{ text: "UPI ID Lookup" }, { text: "Recent History" }],
  [{ text: "Help" }, { text: "Start" }]
];

Bot.sendKeyboard(keyboard, "Aur kuch help chahiye?");