/*CMD
  command: /start
  help: Start the bot
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: start, hello, hi
CMD*/

// Mumbai style greeting
var greetings = [
  "Kya bolti public! UPI Info Lookup Bot pe aapka swagat hai!",
  "Arre dost, kaise ho? UPI ID ke baare mein information nikalne ke liye ready hai apun!",
  "Namaste! Main UPI Info Lookup Bot. Scammers ko track karne ke liye UPI ID ka info nikal sakta hoon!",
  "Aapka time bohot keemti hai, bataiye main kaise help karoon aapki UPI info nikalne mein?"
];

// Get random greeting
var greeting = greetings[Math.floor(Math.random() * greetings.length)];

// Create welcome message
var welcomeMsg = greeting + "\n\n";
welcomeMsg += "🔍 *UPI INFO LOOKUP BOT* 🔍\n\n";
welcomeMsg += "Is bot ka use karke aap kisi bhi UPI ID ki information nikal sakte hain:\n";
welcomeMsg += "- Account holder ka naam\n";
welcomeMsg += "- Bank details\n";
welcomeMsg += "- Location information\n";
welcomeMsg += "- Contact details (if available)\n\n";
welcomeMsg += "Kisi bhi UPI ID ki information nikalne ke liye, bas ye command use karo:\n";
welcomeMsg += "👉 `/upiinfo [UPI ID]`\n\n";
welcomeMsg += "Example: `/upiinfo example@okicici`\n\n";
welcomeMsg += "⚠️ *NOTE*: Is bot ka use sirf scammers ko track karne aur fraud se bachne ke liye kare. Kisi ka personal data misuse na kare.";

// Create keyboard with main options
var keyboard = [
  [{ text: "UPI ID Lookup" }, { text: "Recent History" }],
  [{ text: "Help" }, { text: "About Bot" }]
];

// Send welcome message with keyboard
Bot.sendKeyboard(keyboard, welcomeMsg);

// Store user info for personalization
User.setProperty("first_name", user.first_name, "string");
User.setProperty("last_seen", Date.now(), "integer");

// Initialize user's lookup history if not exists
if(!User.getProperty("lookup_history")){
  User.setProperty("lookup_history", [], "json");
}