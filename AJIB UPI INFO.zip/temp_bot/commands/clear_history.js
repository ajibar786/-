/*CMD
  command: Clear History
  help: Clear UPI lookup history
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 
CMD*/

// Ask for confirmation before clearing history
var keyboard = [
  [{ text: "Yes, Clear History" }, { text: "No, Keep History" }]
];

Bot.sendKeyboard(keyboard, "⚠️ *WARNING*: Kya aap sach mein saari UPI lookup history delete karna chahte hain?");