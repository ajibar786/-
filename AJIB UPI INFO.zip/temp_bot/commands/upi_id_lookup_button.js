/*CMD
  command: UPI ID Lookup
  help: Button for UPI ID lookup
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 
CMD*/

Bot.sendMessage("🔍 UPI ID daalo jiske baare mein information chahiye:");
Bot.runCommand("/ask_upi_id");