/*CMD
  command: /ask_upi_id
  help: Ask for UPI ID
  need_reply: true
  auto_retry_time: 
  folder: 
  answer: UPI ID daalo (e.g., example@okicici):
  keyboard: Cancel
  aliases: 
CMD*/

// Get UPI ID from user input
var upiId = message;

if (upiId.toLowerCase() === "cancel") {
  Bot.sendMessage("UPI lookup cancel kar diya gaya hai.");
  
  // Show main options again
  var keyboard = [
    [{ text: "UPI ID Lookup" }, { text: "Recent History" }],
    [{ text: "Help" }, { text: "About Bot" }]
  ];
  
  Bot.sendKeyboard(keyboard, "Aur kuch help chahiye?");
  return;
}

// Run the upiinfo command with the provided UPI ID
Bot.runCommand("/upiinfo " + upiId);