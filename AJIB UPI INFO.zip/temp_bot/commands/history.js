/*CMD
  command: /history
  help: Show recent UPI lookup history
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: history, recent
CMD*/

// Get user's lookup history
var history = User.getProperty("lookup_history") || [];

if (history.length === 0) {
  Bot.sendMessage("❌ Abhi tak koi UPI lookup history nahi hai. Pehle `/upiinfo` command use karke kisi UPI ID ki information nikalo.");
  return;
}

// Format history for display
var msg = "📜 *RECENT UPI LOOKUP HISTORY* 📜\n\n";

for (var i = 0; i < history.length; i++) {
  var entry = history[i];
  var date = new Date(entry.timestamp);
  var formattedDate = date.toLocaleDateString() + " " + date.toLocaleTimeString();
  
  msg += (i + 1) + ". *UPI ID*: `" + entry.upi_id + "`\n";
  msg += "   *Name*: " + entry.name + "\n";
  msg += "   *Bank*: " + entry.bank + "\n";
  msg += "   *Time*: " + formattedDate + "\n";
  
  // Add command to look up this UPI ID again
  msg += "   👉 `/upiinfo " + entry.upi_id + "`\n\n";
}

msg += "⚠️ *NOTE*: History is stored only for your session and is not shared with others.";

Bot.sendMessage(msg);

// Show main options again
var keyboard = [
  [{ text: "UPI ID Lookup" }, { text: "Clear History" }],
  [{ text: "Help" }, { text: "About Bot" }]
];

Bot.sendKeyboard(keyboard, "Aur kuch help chahiye?");