"""
UPI Info Lookup Bot
Created for extracting information from UPI IDs to track scammers
"""

import requests
import json
import os
import re
import time
import logging
from datetime import datetime
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("upi_lookup_bot.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class UPILookupBot:
    def __init__(self):
        """Initialize the UPI Lookup Bot with necessary configurations"""
        self.api_endpoints = {
            "primary": "https://upibankvalidator.com/api/upiValidate",
            "secondary": "https://upiverify.npci.org.in/api/verify",  # Example backup API
            "fallback": "https://api.vpa-check.npci.in/api/verify"    # Example fallback API
        }
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Accept": "application/json",
            "Content-Type": "application/json"
        }
        self.history_file = Path("upi_lookup_bot/data/lookup_history.json")
        self.ensure_history_file()
        
    def ensure_history_file(self):
        """Ensure the history file exists"""
        if not self.history_file.exists():
            self.history_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self.history_file, "w") as f:
                json.dump([], f)
    
    def validate_upi_id(self, upi_id):
        """Validate if the UPI ID format is correct"""
        upi_pattern = r'^[\w\.\-]+@[\w\.\-]+$'
        return bool(re.match(upi_pattern, upi_id))
    
    def lookup_upi_info(self, upi_id):
        """Look up information for a UPI ID using available APIs"""
        if not self.validate_upi_id(upi_id):
            return {
                "success": False,
                "error": "Invalid UPI ID format",
                "message": "UPI ID format is incorrect. It should be like username@bankname or number@upi"
            }
        
        # Try primary API first
        result = self._try_api_lookup(self.api_endpoints["primary"], upi_id)
        
        # If primary fails, try secondary
        if not result.get("success", False) and "secondary" in self.api_endpoints:
            result = self._try_api_lookup(self.api_endpoints["secondary"], upi_id)
        
        # If secondary fails, try fallback
        if not result.get("success", False) and "fallback" in self.api_endpoints:
            result = self._try_api_lookup(self.api_endpoints["fallback"], upi_id)
        
        # If all APIs fail, use simulated data (for demo purposes)
        if not result.get("success", False):
            result = self._simulate_upi_lookup(upi_id)
        
        # Save lookup to history
        self._save_to_history(upi_id, result)
        
        return result
    
    def _try_api_lookup(self, api_url, upi_id):
        """Try to look up UPI info from a specific API"""
        try:
            payload = {"vpa": upi_id}
            response = requests.post(api_url, headers=self.headers, json=payload, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                
                # Process the response based on API format
                # This would need to be adjusted based on the actual API response structure
                if "data" in data and data.get("status") == "SUCCESS":
                    return {
                        "success": True,
                        "data": data["data"],
                        "source": api_url,
                        "timestamp": datetime.now().isoformat()
                    }
            
            logger.warning(f"API lookup failed for {upi_id} at {api_url}: {response.status_code}")
            return {"success": False, "error": f"API returned status {response.status_code}"}
            
        except Exception as e:
            logger.error(f"Error in API lookup for {upi_id}: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def _simulate_upi_lookup(self, upi_id):
        """Simulate UPI lookup for demonstration purposes"""
        # Extract parts from UPI ID
        parts = upi_id.split("@")
        username = parts[0]
        handle = parts[1].lower()
        
        # Map common UPI handles to banks
        bank_mapping = {
            "oksbi": "State Bank of India",
            "okicici": "ICICI Bank",
            "okhdfc": "HDFC Bank",
            "okaxis": "Axis Bank",
            "okhdfcbank": "HDFC Bank",
            "okpnb": "Punjab National Bank",
            "okbob": "Bank of Baroda",
            "ybl": "Yes Bank",
            "yesbank": "Yes Bank",
            "upi": "BHIM UPI",
            "paytm": "Paytm Payments Bank",
            "ibl": "ICICI Bank",
            "axl": "Axis Bank",
            "kotak": "Kotak Mahindra Bank",
            "apl": "Amazon Pay",
            "okidfcbank": "IDFC First Bank",
            "gpay": "Google Pay",
            "airtel": "Airtel Payments Bank",
            "fbl": "Federal Bank",
            "axisbank": "Axis Bank",
            "sbi": "State Bank of India",
            "icici": "ICICI Bank"
        }
        
        # Determine bank name
        bank_name = "Unknown Bank"
        for key, value in bank_mapping.items():
            if key in handle:
                bank_name = value
                break
        
        # Generate simulated data
        cities = ["Mumbai", "Delhi", "Bangalore", "Hyderabad", "Chennai", "Kolkata", "Pune", "Ahmedabad"]
        states = ["Maharashtra", "Delhi", "Karnataka", "Telangana", "Tamil Nadu", "West Bengal", "Gujarat"]
        
        # Create a deterministic but seemingly random selection based on the UPI ID
        hash_value = sum(ord(c) for c in upi_id)
        city = cities[hash_value % len(cities)]
        state = states[hash_value % len(states)]
        
        # Generate a simulated phone number (for demo purposes only)
        # In a real system, this would come from an actual API
        phone = "+91" + ''.join([str((hash_value + i) % 10) for i in range(10)])
        
        # Create simulated response
        simulated_data = {
            "type": "vpa",
            "name": username.upper(),
            "vpa": upi_id,
            "pspId": str(1000000000 + hash_value % 9000000000),
            "ifsc_info": {
                "DISTRICT": city.upper(),
                "UPI": True,
                "CONTACT": phone,
                "IMPS": True,
                "STATE": state.upper(),
                "SWIFT": "null",
                "NEFT": True,
                "CITY": city.upper(),
                "RTGS": True,
                "ISO3166": "IN-MH",
                "CENTRE": city.upper(),
                "MICR": str(400000000 + hash_value % 1000000),
                "BRANCH": f"{city.upper()} BRANCH",
                "ADDRESS": f"PLOT NO.123, {city.upper()}, PIN - {400000 + hash_value % 100000}",
                "BANK": bank_name,
                "BANKCODE": "BANK" + str(hash_value % 100),
                "IFSC": "IFSC" + str(1000000000 + hash_value % 9000000000)
            },
            "beneficiary_state": "active",
            "user_beneficiary_state": "active"
        }
        
        return {
            "success": True,
            "data": simulated_data,
            "source": "simulation",
            "timestamp": datetime.now().isoformat(),
            "note": "This is simulated data for demonstration purposes only. In a real system, this would come from an actual API."
        }
    
    def _save_to_history(self, upi_id, result):
        """Save lookup result to history file"""
        try:
            # Read existing history
            with open(self.history_file, "r") as f:
                history = json.load(f)
            
            # Add new entry
            entry = {
                "upi_id": upi_id,
                "timestamp": datetime.now().isoformat(),
                "result": result
            }
            
            history.append(entry)
            
            # Write updated history
            with open(self.history_file, "w") as f:
                json.dump(history, f, indent=2)
                
        except Exception as e:
            logger.error(f"Error saving to history: {str(e)}")
    
    def get_lookup_history(self, limit=10):
        """Get recent lookup history"""
        try:
            with open(self.history_file, "r") as f:
                history = json.load(f)
            
            # Return most recent entries
            return history[-limit:]
            
        except Exception as e:
            logger.error(f"Error reading history: {str(e)}")
            return []
    
    def format_lookup_result(self, result, format_type="text"):
        """Format lookup result for display"""
        if not result.get("success", False):
            return f"❌ Lookup Failed: {result.get('error', 'Unknown error')}"
        
        data = result.get("data", {})
        
        if format_type == "json":
            return json.dumps(data, indent=2)
        
        # Format as text
        text_result = "🔍 *UPI LOOKUP RESULT* 🔍\n\n"
        
        # Basic info
        text_result += f"🔹 *UPI ID*: {data.get('vpa', 'N/A')}\n"
        text_result += f"🔹 *Name*: {data.get('name', 'N/A')}\n"
        text_result += f"🔹 *Account Status*: {data.get('beneficiary_state', 'N/A')}\n\n"
        
        # Bank info
        ifsc_info = data.get('ifsc_info', {})
        text_result += f"🏦 *Bank*: {ifsc_info.get('BANK', 'N/A')}\n"
        text_result += f"🔹 *IFSC*: {ifsc_info.get('IFSC', 'N/A')}\n"
        text_result += f"🔹 *Branch*: {ifsc_info.get('BRANCH', 'N/A')}\n\n"
        
        # Location info
        text_result += f"📍 *Location*:\n"
        text_result += f"🔹 *City*: {ifsc_info.get('CITY', 'N/A')}\n"
        text_result += f"🔹 *State*: {ifsc_info.get('STATE', 'N/A')}\n"
        text_result += f"🔹 *Address*: {ifsc_info.get('ADDRESS', 'N/A')}\n\n"
        
        # Contact info (if available)
        if ifsc_info.get('CONTACT'):
            text_result += f"📞 *Contact*: {ifsc_info.get('CONTACT', 'N/A')}\n\n"
        
        # Source info
        text_result += f"ℹ️ *Source*: {result.get('source', 'N/A')}\n"
        text_result += f"⏰ *Timestamp*: {result.get('timestamp', 'N/A')}\n"
        
        if result.get('source') == 'simulation':
            text_result += "\n⚠️ *Note*: This is simulated data for demonstration purposes only."
        
        return text_result

# Example usage
if __name__ == "__main__":
    bot = UPILookupBot()
    result = bot.lookup_upi_info("example@oksbi")
    print(bot.format_lookup_result(result))
    print("\nJSON Format:")
    print(bot.format_lookup_result(result, "json"))