# UPI Info Lookup Bot - Deployment Guide

## Bots.Business Platform Par Deploy Karne Ke Steps

### Step 1: Bots.Business Account Setup
1. [Bots.Business](https://bots.business/) par jaaye
2. Sign up kare ya login kare apne account mein
3. Dashboard par jaaye

### Step 2: New Bot Create Kare
1. Dashboard par "Create Bot" button par click kare
2. Bot ka name enter kare (e.g., "UPI Info Lookup Bot")
3. Bot type "Telegram" select kare
4. "Create" button par click kare

### Step 3: Telegram Bot Token Setup
1. Telegram par [@BotFather](https://t.me/BotFather) se chat kare
2. `/newbot` command send kare
3. Bot ka name aur username provide kare
4. BotFather se API token copy kare
5. Bots.Business dashboard par apne bot ke settings mein jaake API token paste kare

### Step 4: Bot Files Upload Kare
1. Apne bot ke dashboard par "Tools" section mein jaaye
2. "Import bot from ZIP" option select kare
3. Is repository ko ZIP format mein download kare
4. ZIP file ko upload kare

### Step 5: Bot Ko Test Kare
1. Apne Telegram bot ko start kare (`/start` command send kare)
2. Bot ke saare commands test kare:
   - `/help` - Help information dekhe
   - `/upiinfo example@okicici` - UPI ID lookup test kare
   - `/history` - History check kare
   - `/about` - Bot ke baare mein jaane

### Step 6: Bot Ko Customize Kare (Optional)
1. Bot ke responses ko apne hisaab se customize kar sakte hain
2. Commands ke code ko edit karke additional features add kar sakte hain
3. UPI lookup logic ko real API se connect kar sakte hain

## Real UPI API Integration (Advanced)

Agar aap real UPI verification API se connect karna chahte hain, to aapko `/upiinfo.js` file mein `lookupUpiInfo` function ko modify karna hoga:

```javascript
function lookupUpiInfo(upiId) {
  // API URL and headers
  var url = "https://your-upi-api-endpoint.com/verify";
  var headers = {
    "Content-Type": "application/json",
    "Authorization": "Bearer YOUR_API_KEY"
  };
  
  // API request payload
  var payload = {
    "vpa": upiId
  };
  
  // Make API request
  HTTP.post({
    url: url,
    headers: headers,
    body: payload,
    success: function(response) {
      // Parse API response
      var data = JSON.parse(response.content);
      
      // Display UPI info
      displayUpiInfo(data);
      
      // Save to history
      saveToHistory(upiId, data);
    },
    error: function(error) {
      Bot.sendMessage("❌ API error: " + error);
    }
  });
}
```

## Security Considerations

1. API keys aur sensitive information ko secure rakhe
2. User data ko responsibly handle kare
3. Bot ka use sirf legitimate purposes ke liye kare
4. Privacy laws aur regulations ka follow kare

## Troubleshooting

1. **Bot respond nahi kar raha hai**: API token verify kare aur Bots.Business dashboard par bot ka status check kare
2. **Commands kaam nahi kar rahe**: Command syntax check kare aur Bots.Business dashboard par errors dekhe
3. **API errors**: API endpoints aur credentials verify kare

## Support

Kisi bhi technical issue ke liye, Bots.Business support se contact kare ya developer se help le.

---

Created by NinjaTech AI | Version 1.0