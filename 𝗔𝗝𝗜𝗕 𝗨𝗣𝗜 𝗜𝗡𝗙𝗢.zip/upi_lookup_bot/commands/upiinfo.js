/*CMD
  command: /upiinfo
  help: /upiinfo [UPI ID] - Get information about a UPI ID
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: upiinfo, lookup, info
CMD*/

// Check if parameters are provided in the command
var params = params || "";

if (!params) {
  // No parameters provided, ask for UPI ID
  Bot.sendMessage("🔍 UPI ID daalo jiske baare mein information chahiye:");
  Bot.runCommand("/ask_upi_id");
  return;
}

// If parameters are provided, use them as UPI ID
var upiId = params.trim();

// Validate UPI ID format
var upiPattern = /^[\w\.\-]+@[\w\.\-]+$/;
if (!upiPattern.test(upiId)) {
  Bot.sendMessage("❌ UPI ID format galat hai! Sahi format: username@bankname\nExample: merchant@upi");
  Bot.runCommand("/ask_upi_id");
  return;
}

// Show "typing" indicator to simulate processing
Bot.sendMessage("🔄 Fetching UPI info...");

// Perform UPI lookup
lookupUpiInfo(upiId);

function lookupUpiInfo(upiId) {
  // In a real implementation, this would make an API call to a UPI verification service
  // For demonstration, we'll simulate the lookup with realistic data
  
  // Extract parts from UPI ID
  var parts = upiId.split("@");
  var username = parts[0];
  var handle = parts[1].toLowerCase();
  
  // Map common UPI handles to banks
  var bankMapping = {
    "oksbi": "State Bank of India",
    "okicici": "ICICI Bank",
    "okhdfc": "HDFC Bank",
    "okaxis": "Axis Bank",
    "okhdfcbank": "HDFC Bank",
    "okpnb": "Punjab National Bank",
    "okbob": "Bank of Baroda",
    "ybl": "Yes Bank",
    "yesbank": "Yes Bank",
    "upi": "BHIM UPI",
    "paytm": "Paytm Payments Bank",
    "ibl": "ICICI Bank",
    "axl": "Axis Bank",
    "kotak": "Kotak Mahindra Bank",
    "apl": "Amazon Pay",
    "okidfcbank": "IDFC First Bank",
    "gpay": "Google Pay",
    "airtel": "Airtel Payments Bank",
    "fbl": "Federal Bank",
    "axisbank": "Axis Bank",
    "sbi": "State Bank of India",
    "icici": "ICICI Bank"
  };
  
  // Determine bank name
  var bankName = "Unknown Bank";
  for (var key in bankMapping) {
    if (handle.indexOf(key) !== -1) {
      bankName = bankMapping[key];
      break;
    }
  }
  
  // Generate simulated data
  var cities = ["Mumbai", "Delhi", "Bangalore", "Hyderabad", "Chennai", "Kolkata", "Pune", "Ahmedabad"];
  var states = ["Maharashtra", "Delhi", "Karnataka", "Telangana", "Tamil Nadu", "West Bengal", "Gujarat"];
  
  // Create a deterministic but seemingly random selection based on the UPI ID
  var hashValue = 0;
  for (var i = 0; i < upiId.length; i++) {
    hashValue += upiId.charCodeAt(i);
  }
  
  var city = cities[hashValue % cities.length];
  var state = states[hashValue % states.length];
  
  // Generate a simulated phone number (for demo purposes only)
  var phone = "+91";
  for (var i = 0; i < 10; i++) {
    phone += ((hashValue + i) % 10).toString();
  }
  
  // Create simulated response
  var simulatedData = {
    "type": "vpa",
    "name": username.toUpperCase(),
    "vpa": upiId,
    "pspId": (1000000000 + hashValue % 9000000000).toString(),
    "ifsc_info": {
      "DISTRICT": city.toUpperCase(),
      "UPI": true,
      "CONTACT": phone,
      "IMPS": true,
      "STATE": state.toUpperCase(),
      "SWIFT": "null",
      "NEFT": true,
      "CITY": city.toUpperCase(),
      "RTGS": true,
      "ISO3166": "IN-" + state.substring(0, 2).toUpperCase(),
      "CENTRE": city.toUpperCase(),
      "MICR": (400000000 + hashValue % 1000000).toString(),
      "BRANCH": city.toUpperCase() + " BRANCH",
      "ADDRESS": "PLOT NO." + (hashValue % 500 + 1) + ", " + city.toUpperCase() + ", PIN - " + (400000 + hashValue % 100000),
      "BANK": bankName,
      "BANKCODE": "BANK" + (hashValue % 100).toString(),
      "IFSC": "IFSC" + (1000000000 + hashValue % 9000000000).toString()
    },
    "beneficiary_state": "active",
    "user_beneficiary_state": "active"
  };
  
  // Format the response for display
  displayUpiInfo(simulatedData);
  
  // Save to lookup history
  saveToHistory(upiId, simulatedData);
}

function displayUpiInfo(data) {
  // First send JSON format (like in the screenshot)
  var jsonResponse = "```json\n" + JSON.stringify(data, null, 2) + "\n```";
  Bot.sendMessage("📊 *UPI Lookup Result for " + data.vpa + "*:\n" + jsonResponse);
  
  // Then send formatted text for better readability
  var textResponse = "🔍 *UPI LOOKUP RESULT* 🔍\n\n";
  
  // Basic info
  textResponse += "🔹 *UPI ID*: " + data.vpa + "\n";
  textResponse += "🔹 *Name*: " + data.name + "\n";
  textResponse += "🔹 *Account Status*: " + data.beneficiary_state + "\n\n";
  
  // Bank info
  var ifscInfo = data.ifsc_info;
  textResponse += "🏦 *Bank*: " + ifscInfo.BANK + "\n";
  textResponse += "🔹 *IFSC*: " + ifscInfo.IFSC + "\n";
  textResponse += "🔹 *Branch*: " + ifscInfo.BRANCH + "\n\n";
  
  // Location info
  textResponse += "📍 *Location*:\n";
  textResponse += "🔹 *City*: " + ifscInfo.CITY + "\n";
  textResponse += "🔹 *State*: " + ifscInfo.STATE + "\n";
  textResponse += "🔹 *Address*: " + ifscInfo.ADDRESS + "\n\n";
  
  // Contact info
  textResponse += "📞 *Contact*: " + ifscInfo.CONTACT + "\n\n";
  
  // Disclaimer
  textResponse += "⚠️ *NOTE*: This is simulated data for demonstration purposes. In a real implementation, this would come from an actual UPI verification API.";
  
  Bot.sendMessage(textResponse);
  
  // Show main options again
  var keyboard = [
    [{ text: "UPI ID Lookup" }, { text: "Recent History" }],
    [{ text: "Help" }, { text: "About Bot" }]
  ];
  
  Bot.sendKeyboard(keyboard, "Aur kuch help chahiye?");
}

function saveToHistory(upiId, data) {
  // Get existing history
  var history = User.getProperty("lookup_history") || [];
  
  // Add new entry
  var entry = {
    "upi_id": upiId,
    "name": data.name,
    "bank": data.ifsc_info.BANK,
    "timestamp": new Date().toISOString()
  };
  
  // Add to beginning of array
  history.unshift(entry);
  
  // Keep only last 10 entries
  if (history.length > 10) {
    history = history.slice(0, 10);
  }
  
  // Save updated history
  User.setProperty("lookup_history", history, "json");
}