/*CMD
  command: Yes, Clear History
  help: Confirm clearing history
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 
CMD*/

// Clear the user's lookup history
User.setProperty("lookup_history", [], "json");

Bot.sendMessage("✅ UPI lookup history clear kar di gayi hai!");

// Show main options again
var keyboard = [
  [{ text: "UPI ID Lookup" }, { text: "Recent History" }],
  [{ text: "Help" }, { text: "About Bot" }]
];

Bot.sendKeyboard(keyboard, "Aur kuch help chahiye?");