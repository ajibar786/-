/*CMD
  command: About Bot
  help: Button for about bot
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 
CMD*/

Bot.runCommand("/about");