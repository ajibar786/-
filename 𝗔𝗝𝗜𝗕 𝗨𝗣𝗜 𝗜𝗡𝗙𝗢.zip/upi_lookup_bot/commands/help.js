/*CMD
  command: /help
  help: Show help information
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: help, commands, ?
CMD*/

var msg = "🔥 *UPI INFO LOOKUP BOT - COMMANDS LIST* 🔥\n\n";
msg += "Ye raha commands ka list. Koi bhi command use karne ke liye, bas type karo aur bhej do:\n\n";
msg += "👉 */start* - Bot ko start karo\n";
msg += "👉 */help* - Ye help message dekho\n";
msg += "👉 */upiinfo* [UPI ID] - UPI ID ki information nikalo\n";
msg += "👉 */history* - Recent UPI lookups ki history dekho\n";
msg += "👉 */about* - Bot ke baare mein jaano\n\n";
msg += "Example commands:\n";
msg += "*/upiinfo* example@okicici\n";
msg += "*/upiinfo* merchant@paytm\n\n";
msg += "⚠️ *NOTE*: Is bot ka use sirf scammers ko track karne aur fraud se bachne ke liye kare. Kisi ka personal data misuse na kare.";

// Create keyboard with main options
var keyboard = [
  [{ text: "UPI ID Lookup" }, { text: "Recent History" }],
  [{ text: "Start" }, { text: "About Bot" }]
];

// Send help message with keyboard
Bot.sendKeyboard(keyboard, msg);