/*CMD
  command: No, Keep History
  help: Cancel clearing history
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 
CMD*/

Bot.sendMessage("✅ History clear nahi ki gayi hai. Aapki UPI lookup history safe hai.");

// Show main options again
var keyboard = [
  [{ text: "UPI ID Lookup" }, { text: "Recent History" }],
  [{ text: "Help" }, { text: "About Bot" }]
];

Bot.sendKeyboard(keyboard, "Aur kuch help chahiye?");