/*CMD
  command: Recent History
  help: Button for recent history
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 
CMD*/

Bot.runCommand("/history");